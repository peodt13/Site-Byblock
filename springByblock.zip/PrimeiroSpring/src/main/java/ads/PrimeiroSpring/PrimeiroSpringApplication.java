package ads.PrimeiroSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiroSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrimeiroSpringApplication.class, args);

    }

}
