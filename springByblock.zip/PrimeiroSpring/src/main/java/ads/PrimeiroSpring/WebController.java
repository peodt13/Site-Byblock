package ads.PrimeiroSpring;

import com.mycompany.mongocrud.Entrada;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.mycompany.mongocrud.conectaMongo;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WebController {

    @RequestMapping("/pag1")
    public String DigaOla(Model modelo) {
        System.out.println("Chamando o método DigaOlá!");
        modelo.addAttribute("mensagem", "Bem vindo a está maluquice!");
        return "pag1";
    }

    @RequestMapping("/form")
    public String DigaOla2(Model modelo) {
        System.out.println("Estou no form");
        modelo.addAttribute("mensagem2", "Formulario");
        return "form";

    }

    @RequestMapping("/cadastro")
    public String cadastro(Model model) {
        model.addAttribute("cadastroForm", new CadastroForm());
        return "cadastro";
    }

    @RequestMapping(value="/respostaForm", method = RequestMethod.POST)
    public String DigaOla3(Model modelo, String senha, String email) {
        System.out.println("Agora estou no RespostaForm");
        modelo.addAttribute("mensagem3", "Resposta do formulário:\n" + email + " seja bem-vindo\n" + "seu email é: " + email);
        conectaMongo con = new conectaMongo();
        con.insertValues(senha, email);
        con.getValues();
        return "respostaForm";
    }
}
